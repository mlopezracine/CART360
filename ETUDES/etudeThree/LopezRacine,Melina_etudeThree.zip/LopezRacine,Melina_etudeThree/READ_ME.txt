##READ_ME
Documentation on my approach/ description of photos


#circuitBuilding_process01 <br>
This is the first state of the circuit. The LED was not proprelly integrated in the breadboard. <br>
The wires were misplaced, and overall the circuit was messy. <br>

#circuitBuilding_process02 <br>
This is the final version of the circuit (top view). <br>
The wires were cut to limited their trajectory. <br>
The LED is connected to the rest of the circuit. <br>

#circuitBuilding_process03 <br>
This is the final version of the circuit (front view).