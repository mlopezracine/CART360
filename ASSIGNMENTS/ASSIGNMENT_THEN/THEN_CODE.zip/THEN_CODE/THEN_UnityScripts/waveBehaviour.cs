﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class waveBehaviour : MonoBehaviour {

    // Define private variables
	private GameObject boat_GO;         // The boat game object
	private GameObject MANAGER;         // The game's manager game object
	private Vector3 currentPos;         // The coordinate of the current position of the boat
    private float currentDistance;      // The distance between the boat and each instance of waves
    
    // Define public variables
    public float waveLifetime = 3.0f;   // The lifetime of each wave
    public float speed = 3f;            // The speed (movement) of each wave
    public int amount = 1;              // The amount of damage taken 


	// Use this for initialization
	void Start () {
        // Identify the boat game object in the scene with the tag "Boat"
		boat_GO = GameObject.FindGameObjectWithTag("Boat");
        // Identify the MANAGER in the scene with the tag "MANAGER"
		MANAGER = GameObject.FindGameObjectWithTag("MANAGER");
		// Rotate the wave's angle to the direction of the boat
		transform.LookAt(boat_GO.transform);
	}
	
	// Update is called once per frame
	void Update () {
		float step = speed * Time.deltaTime;
		// Change the position of the wave
		Vector3 currentPos = transform.position;
		// Move the wave toward the boat (the rotation is defined at the start function)
		currentDistance = Vector3.Distance(boat_GO.transform.position, currentPos);
		// Move the wave forward, at the defined speed
		transform.Translate(Vector3.forward * step);

		// If the wave hits the boat
		if (currentDistance <= 1f) 
		{
			// The boat takes damage
			MANAGER.GetComponent<spawnBehaviour>().TakeDamage();
			// Destroy this wave instance
			Destroy(this.gameObject);
		
		}
		
        // Keep track of the remaining lifetime of the wave (countdown)
		waveLifetime -= Time.deltaTime;
		// If the wave's lifetime reachs 0
		if(waveLifetime < 0)
		{
			// Destroy this wave instance
         	Destroy(this.gameObject);
         }

	}
}
