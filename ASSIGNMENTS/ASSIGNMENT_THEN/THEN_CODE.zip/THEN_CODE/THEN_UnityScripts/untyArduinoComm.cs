﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text.RegularExpressions;
using System;
using System.IO.Ports;


public class untyArduinoComm : MonoBehaviour {

// Connect to the serial port (Arduino)
SerialPort stream = new SerialPort ("COM3", 9600);
int distanceResponse;

// Define public variables
public GameObject boat;               // The boat object
public GameObject Y0;                 // Game object: East
public GameObject Y1;                 // Game object: Nord
public GameObject Y2;                 // Game object: Nord-East
public GameObject Y3;                 // Game object: Nord-West
public GameObject Y4;                 // Game object: South-East
public GameObject Y5;                 // Game object: South-West
public GameObject Y6;                 // Game object: South
public GameObject Y7;                 // Game object: West

// Define private variables
private GameObject MANAGER;
private GameObject target;

private float updatePeriod = 0.0f;
public float speed = 5f;

// Define the variable for the boat's position
Vector3 TargetPosition;// = new Vector3(0, -0.17f, 0);



	// Use this for initialization
	void Start () {
        // Open the Serial stream
		stream.Open();
		stream.ReadTimeout = 1;
        // Identify the game's manager in the scene with the tag "MANAGER"
        MANAGER = GameObject.FindGameObjectWithTag("MANAGER");
        // Define the starting position of the boat
        Vector3 TargetPosition = new Vector3(0, -0.17f, 0);
	}
	
	// Update is called once per frame
	void Update () {
        // Change the rotation of the boat
		lookAtPIN();
        // Define the speed of the boat
		float step = speed * Time.deltaTime;
		boat.transform.position = Vector3.MoveTowards(boat.transform.position, TargetPosition, step);

		try{
			string value = stream.ReadLine();;

        // Split the string on line breaks.
        // The return value from Split is a string array.
        string[] lines = Regex.Split(value, "\t");

        // If the string contains the letter "_"
        // Change target
        // Move boat to new coordinates
        foreach (string line in lines)
        {
            if (line.Contains("a"))
        	{
        		target = Y0;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("b"))
        	{
        		target = Y0;
        		TargetPosition = new Vector3(5, -0.17f, 0);	
        	}

        	else if (line.Contains("c"))
        	{
        		target = Y0;
        		TargetPosition = new Vector3(14.3f, -0.17f, 0);
        	}

        	else if (line.Contains("d"))
        	{
        		target = Y1;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("e"))
        	{
        		target = Y1;
        		TargetPosition = new Vector3(0, -0.17f, 5);
        	}

        	else if (line.Contains("f"))
        	{
        		target = Y1;
        		TargetPosition = new Vector3(0, -0.17f, 14.3f);
        	}

         	else if (line.Contains("g"))
        	{
        		target = Y2;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("h"))
        	{
        		target = Y2;
        		TargetPosition = new Vector3(5, -0.17f, 5);
        	}

        	else if (line.Contains("i"))
        	{
        		target = Y2;
        		TargetPosition = new Vector3(9.6f, -0.17f, 9.6f);
        	}

        	else if (line.Contains("j"))
        	{
        		target = Y3;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("k"))
        	{
        		target = Y3;
        		TargetPosition = new Vector3(-5, -0.17f, 5);
        	}

        	else if (line.Contains("l"))
        	{
        		target = Y3;
        		TargetPosition = new Vector3(-9.6f, -0.17f, 9.6f);
        	}

        	else if (line.Contains("m"))
        	{
        		target = Y4;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("n"))
        	{
        		target = Y4;
        		TargetPosition = new Vector3(5, -0.17f, -5);
        	}

        	else if (line.Contains("o"))
        	{
        		target = Y4;
        		TargetPosition = new Vector3(9.6f, -0.17f, -9.6f);
        	}

        	else if (line.Contains("p"))
        	{
        		target = Y5;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("q"))
        	{
        		target = Y5;
        		TargetPosition = new Vector3(-5, -0.17f, -5);
        	}

        	else if (line.Contains("r"))
        	{
        		target = Y5;
        		TargetPosition = new Vector3(-9.6f, -0.17f, -9.6f);
        	}

        	else if (line.Contains("s"))
        	{
        		target = Y6;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("t"))
        	{
        		target = Y6;
        		TargetPosition = new Vector3(0, -0.17f, -5);
        	}

        	else if (line.Contains("u"))
        	{
        		target = Y6;
        		TargetPosition = new Vector3(0, -0.17f, -14.3f);
        	}

        	else if (line.Contains("v"))
        	{
        		target = Y7;
        		TargetPosition = new Vector3(0, -0.17f, 0);
        	}

        	else if (line.Contains("w"))
        	{
        		target = Y7;
        		TargetPosition = new Vector3(-5, -0.17f, 0);
        	}

        	else if (line.Contains("x"))
        	{
        		target = Y7;
        		TargetPosition = new Vector3(-14.3f, -0.17f, 0);
        	}

            // Activate function Vortex2
             else if (line.Contains("y"))
            {
                Debug.Log("vortex2");
                MANAGER.GetComponent<spawnBehaviour>().Vortex2();
            }

            // Activate function Vortex1
             else if (line.Contains("z"))
            {
                Debug.Log("vortex1");
                MANAGER.GetComponent<spawnBehaviour>().Vortex1();
            }

        }

		}
		catch(System.Exception){
		}
	}

	void lookAtPIN() {
        // If the boat look at one pin (target)
		if(target != null)
		{
            // Rotate the boat toward the pin (target)
			boat.gameObject.transform.LookAt(target.transform);
		}
	}
}