﻿/********************************************************************************************
* The code used in the update and the spawn functions belong to the user "static_cast"
* The code was found on the Unity answer forum, dated from 12/02/14
* https://answers.unity.com/questions/849214/increasing-spawn-rate-as-game-goes-on.html 
*********************************************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class spawnBehaviour : MonoBehaviour {

  // Define public constantes
  public GameObject enemy;                // The wave prefab to be spawned
  public Transform[] spawnPoints;         // An array of the spawn points waves can spawn from
  private GameObject boat_GO;

  public float nextDrop = 0f;             // The time for the next item to spawn
  public float dropInterval = 10f;        // The interval between spawned items
  public float changeInterval = 30f;      // The interval between changing the interval between spanwed times

  public const int maxHealth = 3;         // The maximum health of the boat
  public int currentHealth = maxHealth;   // The current health start with the maximum health
  public int amount = 1;                  // The amount of damage taken

  // Define public variables (images)
  public Image img1;       
  public Image img2;
  public Image img3;

    void Start ()
    {
      // Identify the boat game object in the scene with the tag "RR"
      boat_GO = GameObject.FindGameObjectWithTag("RR"); 
    }

    void Update()
    {
    if(Time.timeSinceLevelLoad >= nextDrop) //If ready to spawn
    {
      // Call function Spawn();
      Spawn();
      // Set the next spawn time
      nextDrop += dropInterval; 
      // If readu to change the spawn interval
      if(Time.timeSinceLevelLoad >= changeInterval)
      {
        if(dropInterval > 1f) 
        // change the spawn interval to the 3/4ths what is
        dropInterval *= 0.75f;
        else 
        // Make sure dropInterval stays above 1.
        dropInterval = 1f;
      }
    }
  }

    void Spawn ()
    {

        // Find a random index between zero and one less than the number of spawn points.
        int spawnPointIndex = Random.Range (0, spawnPoints.Length);

        // Create an instance of the enemy prefab at the randomly selected spawn point's position and rotation.
        Instantiate (enemy, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);
    }

    /******************************************************************************************** 
    * Whenever the accelerometer receives a raw value (acceleration) greater than 355,
    * the Arduino's serial monitor will print a letter, which will then be pick up by Unity.
    * Vortex1 is invoked when the analogPrint the letter "z", 
    * Vortex2 is invoked when the analogPrint the letter "x".
    ********************************************************************************************/
    public void Vortex1()
    {
      // Create new waves
      Instantiate(enemy, spawnPoints[0].position, spawnPoints[0].rotation);
      Instantiate(enemy, spawnPoints[1].position, spawnPoints[1].rotation);
      Instantiate(enemy, spawnPoints[6].position, spawnPoints[6].rotation);
      Instantiate(enemy, spawnPoints[7].position, spawnPoints[7].rotation); 
    }

    public void Vortex2()
    {
      // Create new waves
      Instantiate(enemy, spawnPoints[2].position, spawnPoints[2].rotation);
      Instantiate(enemy, spawnPoints[3].position, spawnPoints[3].rotation);
      Instantiate(enemy, spawnPoints[4].position, spawnPoints[4].rotation);
      Instantiate(enemy, spawnPoints[5].position, spawnPoints[5].rotation); 
    }


    /******************************************************************************************** 
    * Whenever the boat is hit with a wave, take damage.
    ********************************************************************************************/
    public void TakeDamage()
    {
        // Reduce the current health by the defined amount (1)
        currentHealth -= amount;
        // If the current health reachs 0
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            Debug.Log("Dead!");
            // Load scene
            SceneManager.LoadScene("scene_02");
        }
        // If the current health reachs 2
        if(currentHealth == 2)
        {
          // Remove one heart
          // The total number of heart on screen should be 2
          img3.enabled = !img3.enabled;
        }
        // If the current healt reachs 1
        else if(currentHealth == 1)
        {
          // Remove one heart
          // The total number of heart on screen should be 1
          img2.enabled = !img2.enabled;
        }

        else if (currentHealth == 0)
        {
          // Remove one heart
          // The total number of heart on screen should be 0
          img1.enabled = !img1.enabled;
        }
    }
}
